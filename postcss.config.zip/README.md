This is jsut for assesment of internship not for more then that but with this I had gained lot of practice with useing of components and routing in react and many more concept with this assesment .
** STEPS TO RUN THIS ASSESMENT PROJECT IN YOUR LOCAL MACHINE **
STEP1: Clone this repository in your system
STEP2: Open this code file in any code editor and then open terminal
STEP3:Go to the code folder and then type { npm init } 
its first command to reinstall all the dependency and versions
STEP4: Now run the project by command { npm run dev }
or may go through the package.json file and you can get all the details

# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

|| Thanks you ||
