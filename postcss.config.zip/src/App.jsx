import { useState } from 'react'
import './App.css'
import Header from './components/Header/Header.jsx'
function App() {
 

  return (
    <>
    <h1>Hello</h1>
    <Header/>
    
   
    <Footer/>
    </>
  )
}

export default App
