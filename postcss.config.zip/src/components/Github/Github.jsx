import React from 'react'

function Github() {
  return (
    <div className='bg-gray-500 text-center text-4xl m-4 p-4 text-white'>
      Github Followers : 
    </div>
  )
}

export default Github
